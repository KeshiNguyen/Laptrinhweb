<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Convert</title>
    </head>
    <body>
        <div>
        
    
        <form action="data1.php" name="convert" autocomplete="off">
            <table>
                <tr>
                    <td style="font-size:300%">Enter Input: </td>
                    <td><input type="text" id="input" name="input" style="width: 100x; font-size:200%"></td>

                </tr>
                <tr>
                    <td>
                        <button type="submit" name ="convert" class="btn" value="1" style="font-size:100%" >Convert Radian To Degree</button>
                        <button type="submit" name ="convert" class="btn" value="2"style="font-size:100%">Convert Degree To Radian</button>
                        <button type="reset" title="reset" class="btn" style="font-size:100%">Reset</button>
                    </td>
                </tr>
            </table>
            </form>
        </div>
    </body>
</html>